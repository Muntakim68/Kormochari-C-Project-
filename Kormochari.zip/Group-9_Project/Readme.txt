KormoChari 

Softwares and Frameworks used:

1. Microsoft Visual Studio 2019 Version 16.11.8
2. .NET Framework 4.7.2
3. Microsoft SQL Server 2019
4. Microsoft SQL Server 2019 Management Studio 18.10

Overall Project Features are mentioned in the Project Proposal.

Installation Guide:

Go to Kormochari -> bin -> Debug -> KormoChari.exe

User Guide:

1. Go to Sart Page and click on START button or click About Us to see developer information.
2. Then click on Register Admin button and fill the boxes and click SIGN UP button to create an admin account.
2. Go to Admin Login, enter User ID and User Password then click on LOG IN button(to see typed password click the checkbox) to log in successfully.
3. After logging in, you can see the Dashboard of Admin.
4. If you click on the ? button , to see guideline for icon operation.
5. When you click on Register icon, it will take ypu to employee registration page where you can add/update/delete/show employee datas.
6. Press left arrow icon to return to dashboard and Click on Search Details icon and enter ID to search employee details and bell icon to see their Applications requests,click on next of prev button to navigate through the notices,send them replies by entering in the box and press Send button.
7. Press left arrow icon to return to dashboard and Click on Salary icon and enter employee id and working days and click on Search buttonto see salary details of employees.
8. When finished click on LogOut button to logout from admin system.
9. Press left arrow icon to return to Login Prompt page and click on Employee Login page enter User ID and User Password then click on LOG IN button(to see typed password click the checkbox) to log in successfully.
10. After logging in, you can see the Dashboard of Employee.
11. Click on Profile icon to see the details of the employee user logged in.
12. Press left arrow icon to return to Dashboard and click on Notice Board icon to notices given from the admin, click on next of prev button to navigate through the notices.
13. Press left arrow icon to return to Dashboard and click on Leave Application icon, enter days,id and reason in their respective boxes and press Apply button to send leave application to admin.

Developed By:

1.MUNTAKIM MUSTAFA -> 19-41616-3
2.MD.TOWHID AHMED -> 19-39601-1
3.SHOHANUR RAHMAN SHIHAB -> 20-42080-1

Project Limitations:

1. It is not an web based application. 
2. UI quality is average.

Supervised By:

MD. NAZMUL HOSSAIN
Lecturer 
American International University Bangladesh

We want to dedicate our project to our honourable Sir who gave excellent effort to teach us.